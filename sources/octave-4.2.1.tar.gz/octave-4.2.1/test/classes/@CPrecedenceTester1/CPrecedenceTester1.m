function x = CPrecedenceTester1 ()

  x = struct ('useless_data', pi);
  x = class (x, 'CPrecedenceTester1');

  % don't change anything as far as precedence is concerned

end
