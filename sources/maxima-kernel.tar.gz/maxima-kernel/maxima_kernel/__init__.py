"""
Minimal Maxima Jupyter Kernel

A basic proof-of-concept kernel that wraps Maxima CAS.
"""

import base64
import os
import re
import sys
import tempfile
import pexpect
from ipykernel.kernelbase import Kernel

# Plot functions and their option syntax
PLOT_FAMILY = {'plot2d', 'plot3d', 'contour_plot', 'plotdf', 'ploteq', 'mandelbrot', 'julia'}
DRAW_FAMILY = {'draw', 'draw2d', 'draw3d'}

DEBUG = True

def debug(msg):
    if DEBUG:
        print(f"[MAXIMA DEBUG] {msg}", file=sys.stderr)


def clean_latex(tex: str) -> str:
    """Clean up Maxima's TeX output for MathJax compatibility."""
    # Fix matrix environments - Maxima outputs TeX/LaTeX compatibility code
    # \ifx\endpmatrix\undefined\pmatrix{\else\begin{pmatrix}\fi ... \ifx\endpmatrix\undefined}\else\end{pmatrix}\fi
    tex = re.sub(
        r'\\ifx\\endpmatrix\\undefined\\pmatrix\{\\else\\begin\{pmatrix\}\\fi',
        r'\\begin{pmatrix}',
        tex
    )
    tex = re.sub(
        r'\\ifx\\endpmatrix\\undefined\}\\else\\end\{pmatrix\}\\fi',
        r'\\end{pmatrix}',
        tex
    )
    # \cr is plain TeX for row break, LaTeX uses \\
    tex = tex.replace('\\cr ', '\\\\ ')
    tex = tex.replace('\\cr\n', '\\\\\n')
    tex = re.sub(r'\\cr$', r'\\\\', tex)
    # Remove trailing \\ before \end{pmatrix}
    tex = re.sub(r'\\\\\s*\\end\{pmatrix\}', r'\\end{pmatrix}', tex)

    return tex


def detect_plot_function(code: str) -> tuple[str | None, str | None]:
    """
    Detect if code contains a plot function call.

    Returns (function_name, family) or (None, None) if no plot detected.
    Family is 'plot' or 'draw'.
    """
    # Match function calls like plot2d(...), draw2d(...), etc.
    # This is a simple heuristic - matches the first plot function found
    all_funcs = PLOT_FAMILY | DRAW_FAMILY
    pattern = r'\b(' + '|'.join(all_funcs) + r')\s*\('
    match = re.search(pattern, code)
    if match:
        func = match.group(1)
        family = 'plot' if func in PLOT_FAMILY else 'draw'
        return func, family
    return None, None


def inject_plot_options(code: str, family: str, output_file: str) -> str:
    """
    Inject output file options into plot code.

    For plot family: adds [gnuplot_term, pngcairo], [gnuplot_out_file, "..."]
    For draw family: adds terminal=png, file_name="..."
    """
    code = code.strip()

    # Remove trailing semicolon/dollar for manipulation
    terminator = ''
    if code.endswith(';') or code.endswith('$'):
        terminator = code[-1]
        code = code[:-1].rstrip()

    # Remove .png extension for draw family (it adds its own)
    draw_file = output_file.replace('.png', '') if family == 'draw' else output_file

    if family == 'plot':
        # Find the last closing paren and insert before it
        # plot2d(sin(x), [x,0,6]) -> plot2d(sin(x), [x,0,6], [gnuplot_term, pngcairo], ...)
        last_paren = code.rfind(')')
        if last_paren != -1:
            options = f', [gnuplot_term, pngcairo], [gnuplot_out_file, "{output_file}"]'
            code = code[:last_paren] + options + code[last_paren:]
    else:  # draw family
        # draw2d(explicit(...)) -> draw2d(explicit(...), terminal=png, file_name="...")
        last_paren = code.rfind(')')
        if last_paren != -1:
            options = f', terminal=png, file_name="{draw_file}"'
            code = code[:last_paren] + options + code[last_paren:]

    return code + terminator


class MaximaREPL:
    """Wraps a persistent Maxima REPL session using pexpect."""

    PROMPT_PATTERN = r'\(%i\d+\)'
    OUTPUT_PATTERN = r'\(%o\d+\)'

    def __init__(self):
        self.proc = pexpect.spawn('maxima', encoding='utf-8', timeout=30)
        self.proc.expect(self.PROMPT_PATTERN)

        # Disable 2D display for cleaner parsing
        self._init_session()

    def _init_session(self):
        """Configure Maxima session for programmatic use."""
        self.execute('display2d: false$')

    def execute(self, code: str) -> dict:
        """
        Execute code in Maxima and return parsed result.

        Returns dict with:
            - result: the output value (or None)
            - latex: LaTeX representation (or None)
            - error: error message (or None)
            - raw: raw output for debugging
        """
        code = code.strip()
        if not code:
            return {'result': None, 'latex': None, 'error': None, 'raw': ''}

        # Auto-append semicolon if missing terminator
        if not re.search(r'[;$]\s*$', code):
            code = code + ';'

        # Send code to Maxima
        self.proc.sendline(code)
        self.proc.expect(self.PROMPT_PATTERN)
        raw = self.proc.before

        # Parse the output
        result = self._parse_output(raw)

        # If we got a result (not an error), get LaTeX version
        latex = None
        if result.get('result') and not result.get('error'):
            latex = self._get_latex()

        result['latex'] = latex
        result['raw'] = raw
        return result

    def _parse_output(self, raw: str) -> dict:
        """Parse Maxima's raw output into structured result."""
        lines = raw.strip().split('\n')

        result = None
        error = None

        for line in lines:
            line = line.strip()

            # Check for error markers
            if 'incorrect syntax' in line.lower() or 'error' in line.lower():
                error = line
                continue

            # Look for output line: (%oN) value
            match = re.match(r'\(%o\d+\)\s*(.*)', line)
            if match:
                result = match.group(1).strip()

        return {'result': result, 'error': error}

    def _get_latex(self) -> str | None:
        """Get LaTeX representation of the last result using tex1(%)."""
        self.proc.sendline('tex1(%);')
        self.proc.expect(self.PROMPT_PATTERN)
        raw = self.proc.before

        # Parse the tex1 output
        for line in raw.strip().split('\n'):
            match = re.match(r'\(%o\d+\)\s*(.*)', line.strip())
            if match:
                latex = match.group(1).strip()
                # tex1 returns false if there's no previous result
                if latex and latex != 'false':
                    # Strip surrounding quotes from tex1 output
                    if latex.startswith('"') and latex.endswith('"'):
                        latex = latex[1:-1]
                    # Unescape backslashes (Maxima escapes them in string output)
                    latex = latex.replace('\\\\', '\\')
                    # Clean up for MathJax compatibility
                    latex = clean_latex(latex)
                    return latex
        return None

    def get_completions(self, prefix: str) -> list[tuple[str, str]]:
        """
        Get symbol completions for a prefix using apropos.

        Returns list of (symbol, type) tuples where type is one of:
        'function', 'constant', 'variable', 'keyword'
        """
        if not prefix:
            return []

        # Use apropos to find matching symbols
        self.proc.sendline(f'apropos("{prefix}");')
        self.proc.expect(self.PROMPT_PATTERN)
        raw = self.proc.before

        # Parse the list output: [symbol1, symbol2, ...]
        completions = []
        for line in raw.split('\n'):
            match = re.match(r'\(%o\d+\)\s*\[(.*)', line.strip())
            if match:
                # Start of list
                content = match.group(1)
            elif line.strip().startswith('['):
                content = line.strip()[1:]
            else:
                content = line.strip()

            # Extract symbols from content
            # Symbols are separated by commas, may span multiple lines
            symbols = re.findall(r'[\w_]+', content)
            completions.extend(symbols)

        # Filter to only those starting with the prefix (apropos does substring match)
        completions = [s for s in completions if s.lower().startswith(prefix.lower())]

        # Add type hints based on naming conventions
        typed_completions = []
        for sym in sorted(set(completions)):
            sym_type = self._guess_symbol_type(sym)
            typed_completions.append((sym, sym_type))

        return typed_completions

    def _guess_symbol_type(self, symbol: str) -> str:
        """Guess the type of a symbol based on naming conventions."""
        # Constants start with %
        if symbol.startswith('%'):
            return 'constant'
        # Predicates end with 'p'
        if symbol.endswith('p') and len(symbol) > 1:
            return 'function'
        # Common function patterns
        if any(symbol.startswith(p) for p in ['is', 'make', 'set', 'get', 'print', 'load', 'save']):
            return 'function'
        # Variables/options often have underscores
        if '_' in symbol and not symbol.endswith('_'):
            return 'variable'
        # Default to function (most Maxima symbols are functions)
        return 'function'

    def get_documentation(self, symbol: str) -> str | None:
        """Get documentation for a symbol using describe."""
        if not symbol:
            return None

        # Use describe to get documentation
        self.proc.sendline(f'describe({symbol});')
        self.proc.expect(self.PROMPT_PATTERN, timeout=5)
        raw = self.proc.before

        # Clean up the output
        lines = raw.split('\n')
        doc_lines = []
        in_doc = False

        for line in lines:
            # Skip the input echo
            if f'describe({symbol})' in line:
                in_doc = True
                continue
            # Skip the output marker
            if re.match(r'\(%o\d+\)', line.strip()):
                continue
            if in_doc:
                doc_lines.append(line.rstrip())

        doc = '\n'.join(doc_lines).strip()

        # Check if no documentation found
        if 'No exact match' in doc or not doc:
            return None

        return doc

    def interrupt(self):
        """Send interrupt signal to Maxima."""
        import signal
        if self.proc.isalive():
            self.proc.kill(signal.SIGINT)

    def shutdown(self):
        """Cleanly terminate the Maxima process."""
        try:
            self.proc.sendline('quit();')
            self.proc.close()
        except Exception:
            self.proc.terminate(force=True)


class MaximaKernel(Kernel):
    """Jupyter kernel for Maxima CAS."""

    implementation = 'maxima'
    implementation_version = '0.1.0'
    language = 'maxima'
    language_version = '5.47'  # adjust to your Maxima version
    language_info = {
        'name': 'maxima',
        'mimetype': 'text/x-maxima',
        'file_extension': '.mac',
        'codemirror_mode': 'mathematica',  # closest built-in mode
        'pygments_lexer': 'maxima',
    }
    banner = "Maxima Jupyter Kernel - A simple Maxima CAS interface"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.maxima = MaximaREPL()
        # Create temp directory for plot files
        self._plot_dir = tempfile.mkdtemp(prefix='maxima_plots_')
        self._plot_counter = 0
        # Load draw package for draw functions
        self.maxima.execute('load(draw)$')

    def do_execute(self, code, silent, store_history=True,
                   user_expressions=None, allow_stdin=False):
        """Execute Maxima code and return the result."""
        debug(f"do_execute called with code: {repr(code)}")
        debug(f"silent={silent}")

        # Skip empty code
        if not code.strip():
            debug("Empty code, returning success")
            return self._success()

        # Check for plot commands
        plot_func, plot_family = detect_plot_function(code)
        plot_file = None

        if plot_func:
            debug(f"Detected plot function: {plot_func} (family: {plot_family})")
            self._plot_counter += 1
            plot_file = os.path.join(self._plot_dir, f"plot_{self._plot_counter}.png")
            code = inject_plot_options(code, plot_family, plot_file)
            debug(f"Injected plot options, new code: {code}")

        # Execute in Maxima
        output = self.maxima.execute(code)
        debug(f"Maxima output: {output}")

        # Handle errors
        if output.get('error'):
            debug(f"Error detected: {output['error']}")
            self.send_response(self.iopub_socket, 'stream', {
                'name': 'stderr',
                'text': output['error']
            })
            return {
                'status': 'error',
                'execution_count': self.execution_count,
                'ename': 'MaximaError',
                'evalue': output['error'],
                'traceback': []
            }

        # If this was a plot, display the image
        if plot_file and os.path.exists(plot_file):
            debug(f"Plot file created: {plot_file}")
            self._display_image(plot_file)
        elif not silent and output.get('result'):
            # Send result if not silent (and not a plot)
            data = {'text/plain': output['result']}

            # Add LaTeX if available
            if output.get('latex'):
                data['text/latex'] = f"${output['latex']}$"

            debug(f"Sending execute_result with data: {data}")
            self.send_response(self.iopub_socket, 'execute_result', {
                'execution_count': self.execution_count,
                'data': data,
                'metadata': {}
            })
        else:
            debug(f"Not sending result: silent={silent}, result={output.get('result')}")

        return self._success()

    def _display_image(self, filepath: str):
        """Read an image file and send it to Jupyter for display."""
        try:
            with open(filepath, 'rb') as f:
                image_data = base64.b64encode(f.read()).decode('utf-8')

            self.send_response(self.iopub_socket, 'display_data', {
                'data': {
                    'image/png': image_data
                },
                'metadata': {}
            })
        except Exception as e:
            debug(f"Error displaying image: {e}")
            self.send_response(self.iopub_socket, 'stream', {
                'name': 'stderr',
                'text': f"Error displaying plot: {e}"
            })

    def _success(self):
        """Return a successful execution result."""
        return {
            'status': 'ok',
            'execution_count': self.execution_count,
            'payload': [],
            'user_expressions': {}
        }

    def do_shutdown(self, restart):
        """Handle kernel shutdown."""
        debug("Shutting down Maxima")
        self.maxima.shutdown()
        return {'status': 'ok', 'restart': restart}

    async def do_interrupt(self):
        """Handle interrupt request (stop button)."""
        debug("Interrupt requested")
        self.maxima.interrupt()

    def do_is_complete(self, code):
        """Check if code is complete (ends with ; or $)."""
        code = code.strip()
        if not code:
            return {'status': 'incomplete', 'indent': ''}
        if code.endswith(';') or code.endswith('$'):
            return {'status': 'complete'}
        return {'status': 'incomplete', 'indent': '  '}

    def do_complete(self, code, cursor_pos):
        """Handle tab completion requests."""
        # Extract the token being completed (word before cursor)
        code_to_cursor = code[:cursor_pos]

        # Find the start of the current token
        # Tokens are alphanumeric + underscore
        match = re.search(r'[\w_]+$', code_to_cursor)
        if match:
            prefix = match.group(0)
            start = cursor_pos - len(prefix)
        else:
            prefix = ''
            start = cursor_pos

        debug(f"do_complete: prefix={repr(prefix)}, cursor_pos={cursor_pos}")

        # Get completions from Maxima (returns list of (symbol, type) tuples)
        try:
            typed_matches = self.maxima.get_completions(prefix)
            debug(f"do_complete: found {len(typed_matches)} matches")
        except Exception as e:
            debug(f"do_complete error: {e}")
            typed_matches = []

        # Extract just the symbol names for matches
        matches = [sym for sym, _ in typed_matches]

        # Build type metadata for JupyterLab
        # Format: {'_jupyter_types_experimental': [{'text': sym, 'type': type}, ...]}
        type_info = [
            {'text': sym, 'type': sym_type}
            for sym, sym_type in typed_matches
        ]

        return {
            'status': 'ok',
            'matches': matches,
            'cursor_start': start,
            'cursor_end': cursor_pos,
            'metadata': {
                '_jupyter_types_experimental': type_info
            },
        }

    def do_inspect(self, code, cursor_pos, detail_level=0, omit_sections=()):
        """Handle shift+tab inspection requests."""
        debug(f"do_inspect called: code={repr(code)}, cursor_pos={cursor_pos}")

        # Extract the token at cursor position
        # Look for a complete token around the cursor
        before = code[:cursor_pos]
        after = code[cursor_pos:]

        # Get the token before cursor
        match_before = re.search(r'[\w_]+$', before)
        match_after = re.match(r'^[\w_]+', after)

        token = ''
        if match_before:
            token = match_before.group(0)
        if match_after:
            token += match_after.group(0)

        debug(f"do_inspect: token={repr(token)}")

        if not token:
            return {'status': 'ok', 'found': False, 'data': {}, 'metadata': {}}

        # Get documentation from Maxima
        try:
            doc = self.maxima.get_documentation(token)
            debug(f"do_inspect: doc found = {doc is not None}")
        except Exception as e:
            debug(f"do_inspect error: {e}")
            doc = None

        if doc:
            return {
                'status': 'ok',
                'found': True,
                'data': {
                    'text/plain': doc,
                },
                'metadata': {},
            }
        else:
            return {'status': 'ok', 'found': False, 'data': {}, 'metadata': {}}


if __name__ == '__main__':
    from ipykernel.kernelapp import IPKernelApp
    IPKernelApp.launch_instance(kernel_class=MaximaKernel)
