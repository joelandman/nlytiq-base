# fC.m
function y = fC (x)
  y = x;
endfunction
