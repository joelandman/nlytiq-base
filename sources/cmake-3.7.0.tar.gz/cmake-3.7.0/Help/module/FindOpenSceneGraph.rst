.. cmake-module:: ../../Modules/FindOpenSceneGraph.cmake
