# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A lightweight Jupyter kernel for the Maxima computer algebra system, written in Python. Uses pexpect to maintain a persistent Maxima REPL session.

## Development Commands

```bash
# Setup
python3 -m venv venv
source venv/bin/activate
pip install -e .

# Install kernel spec into Jupyter
python install.py

# Run Jupyter to test
jupyter lab  # or jupyter notebook
```

## Architecture

### Core Components (`maxima_kernel/__init__.py`)

- **MaximaREPL**: Wraps a persistent Maxima process via pexpect
  - Parses output using prompt patterns (`(%iN)`, `(%oN)`)
  - `execute()`: Runs code, auto-appends `;` if missing, returns structured result with LaTeX
  - `get_completions()`: Uses `apropos()` for tab completion
  - `get_documentation()`: Uses `describe()` for Shift+Tab help

- **MaximaKernel**: ipykernel-based Jupyter kernel
  - `do_execute()`: Detects plot commands, injects output options, handles LaTeX rendering
  - `do_complete()`: Tab completion with type hints
  - `do_inspect()`: Shift+Tab documentation lookup

### Plot Handling

Two plot families with different option syntax:
- **plot family** (`plot2d`, `plot3d`, `contour_plot`, `plotdf`, `ploteq`, `mandelbrot`, `julia`): Uses `[gnuplot_term, pngcairo], [gnuplot_out_file, "..."]`
- **draw family** (`draw`, `draw2d`, `draw3d`): Uses `terminal=png, file_name="..."`

Plot options are injected automatically before the closing paren of the function call.

### LaTeX Processing

`clean_latex()` transforms Maxima's TeX output for MathJax compatibility:
- Converts TeX/LaTeX conditional matrix code to standard `\begin{pmatrix}...\end{pmatrix}`
- Replaces `\cr` (Plain TeX) with `\\` (LaTeX)
- Unescapes double backslashes

### Type Guessing

Symbol types for completions are guessed from naming conventions since calling `properties()` is too slow:
- `%...` → constant
- `...p` (predicates) → function
- `is...`, `make...`, `set...` prefixes → function
- Contains `_` (not suffix) → variable
- Default → function
