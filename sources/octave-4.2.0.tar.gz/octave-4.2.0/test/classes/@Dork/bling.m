function out = bling (m1, m2)

  out = 1;

end
