function a = arg_ret
  a = 10;
  f;
  function a = f
    a = 5;
  endfunction
endfunction
