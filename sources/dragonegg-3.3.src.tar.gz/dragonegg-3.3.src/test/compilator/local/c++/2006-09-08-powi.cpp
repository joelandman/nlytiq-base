#include <cmath>

double foo(double X, int Y) {
  return std::pow(X, Y);
}
