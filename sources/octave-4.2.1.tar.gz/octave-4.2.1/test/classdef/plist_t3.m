classdef plist_t3
  properties
    a = 1
    b
  end
end
