.. _stdlib-index:

############################
 The Julia Standard Library
############################

.. toctree::
   :maxdepth: 1

   base
   collections
   math
   numbers
   strings
   arrays
   parallel
   linalg
   constants
   file
   io-network
   punctuation
   sort
   pkg
   dates
   test
   c
   libc
   libdl
   profile
   simd-types
