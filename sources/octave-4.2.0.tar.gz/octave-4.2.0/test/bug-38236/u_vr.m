# u_vr.m

## define and exectute "__demo__" once
eval ("function __demo__ ();  df_vr;  v = vr * 2; endfunction");
__demo__;

## clear definition of "__demo__"
clear __demo__

## define and exectute "__demo__" once more
eval ("function __demo__ ();  df_vr;  v = vr * 2; endfunction");
__demo__;
