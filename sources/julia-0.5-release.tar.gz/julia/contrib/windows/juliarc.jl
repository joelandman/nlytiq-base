# Set up environment for Julia Windows binary distribution
ENV["PATH"] = JULIA_HOME*";"*ENV["PATH"]
