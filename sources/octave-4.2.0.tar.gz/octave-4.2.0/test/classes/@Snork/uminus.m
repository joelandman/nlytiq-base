function s = uminus (s1)

  s = s1;
  s.gick = - s.gick;

end
