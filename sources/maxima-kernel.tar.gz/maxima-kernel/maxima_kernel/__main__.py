"""Entry point for running as: python -m maxima_kernel"""
from ipykernel.kernelapp import IPKernelApp
from . import MaximaKernel

if __name__ == '__main__':
    IPKernelApp.launch_instance(kernel_class=MaximaKernel)
