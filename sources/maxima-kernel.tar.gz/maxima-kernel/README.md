# Maxima Jupyter Kernel

A lightweight Jupyter kernel for the Maxima computer algebra system, written in Python.

## Features Implemented

### Core Functionality
- **Code execution**: Persistent Maxima session via pexpect
- **Auto-semicolon**: Automatically appends `;` if missing (no need to type it)
- **LaTeX rendering**: Results displayed with MathJax via `tex1()`
- **LaTeX cleanup**: Fixes Maxima's TeX/LaTeX compatibility code for MathJax (matrices, `\cr` → `\\`, etc.)

### Plotting
- **Automatic plot detection**: Recognizes `plot2d`, `plot3d`, `contour_plot`, `plotdf`, `ploteq`, `mandelbrot`, `julia`
- **Draw package support**: Recognizes `draw`, `draw2d`, `draw3d`
- **Inline display**: Plots automatically rendered as PNG in notebook

### Interactive Features
- **Tab completion**: Press Tab to complete Maxima symbols (uses `apropos()`)
- **Type hints**: Completions show type (function, constant, variable) based on naming conventions
- **Shift+Tab help**: Shows documentation for symbol under cursor (uses `describe()`)
- **Code completeness**: Detects if input needs `;` or `$` terminator

### Kernel Management
- **Interrupt handling**: Stop button sends SIGINT to Maxima
- **Clean shutdown**: Sends `quit();` to Maxima on kernel shutdown

### Syntax Highlighting
- **Pygments lexer**: `maxima` (built-in) for HTML exports
- **CodeMirror mode**: `mathematica` (approximate) for live editing

## Installation

```bash
# Create and activate venv
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install ipykernel pexpect

# Install package in development mode
pip install -e .

# Install kernel spec
python install.py
```

## Usage

```bash
source venv/bin/activate
jupyter lab  # or jupyter notebook
# Create new notebook → select "Maxima" kernel
```

### Examples

```maxima
/* Basic math - no semicolon needed */
2 + 2

/* Calculus */
diff(x^3, x)
integrate(sin(x), x)

/* Matrices render nicely */
matrix([1,2,3], [4,5,6], [7,8,9])

/* Plots display inline */
plot2d(sin(x), [x, 0, 2*%pi])
draw2d(explicit(exp(-x)*sin(x), x, 0, 10))
```

## Project Structure

```
maxima-kernel/
├── maxima_kernel/
│   ├── __init__.py      # MaximaREPL + MaximaKernel classes
│   ├── __main__.py      # Entry point for python -m
│   └── kernel.json      # Kernel spec template
├── install.py           # Registers kernel with Jupyter
├── pyproject.toml       # Package definition
└── venv/
```

## Remaining Features (TODO)

### From maxima-jupyter not yet implemented:

1. **Display functions**
   - `jupyter_latex("\\frac{a}{b}")` - explicit LaTeX display
   - `jupyter_markdown("# Header")` - markdown display
   - `jupyter_html("<table>...")` - HTML display
   - `jupyter_svg("<svg>...")` - SVG display
   - `jupyter_png()`, `jupyter_jpeg()` - image data display

2. **Lisp mode**
   - `to_lisp()` - switch to Common Lisp evaluation
   - `to_maxima()` - switch back to Maxima

3. **Debugger**
   - Step-by-step execution
   - Breakpoints
   - Variable inspection

4. **Proper syntax highlighting**
   - Custom CodeMirror mode for Maxima (requires JupyterLab extension)
   - maxima-jupyter has `maxima.js` with full Maxima syntax support

### Other improvements:

5. **Better error handling**
   - Parse multi-line errors
   - Distinguish warnings from errors
   - Better error formatting

6. **Plot improvements**
   - SVG output option (better quality)
   - Plot size configuration
   - Interactive plots (plotly?)

7. **Session management**
   - Save/restore session state
   - History persistence

8. **Performance**
   - Cache completions
   - Lazy-load draw package

## Differences from maxima-jupyter

| Feature | This Kernel | maxima-jupyter |
|---------|-------------|----------------|
| Language | Python | Common Lisp |
| Session management | pexpect | Native Lisp |
| LaTeX | `tex1()` + cleanup | `tex1()` + mactex-utilities |
| Plots | PNG via gnuplot options | PNG via gnuplot |
| Completion | `apropos()` | `apropos()` |
| Documentation | `describe()` | `cl-info` |
| Display functions | Not implemented | Full suite (latex, html, markdown, etc.) |
| Lisp mode | Not implemented | Supported |
| Debugger | Not implemented | Full debugger |
| Syntax highlighting | Mathematica mode (approx) | Custom CodeMirror mode |
| Dependencies | ipykernel, pexpect | cl-jupyter, quicklisp, zeromq |
| Installation | pip + python | quicklisp + ASDF |

### Advantages of this kernel:
- **Simpler installation**: Just pip install
- **Easier to hack**: Python is more accessible than Common Lisp
- **Lighter weight**: Fewer dependencies

### Advantages of maxima-jupyter:
- **Native integration**: Direct Lisp-to-Lisp communication
- **More features**: Display functions, debugger, Lisp mode
- **Proper syntax highlighting**: Custom CodeMirror mode

## Technical Notes

### LaTeX Cleanup

Maxima outputs TeX with Plain TeX/LaTeX compatibility code:
```tex
\ifx\endpmatrix\undefined\pmatrix{\else\begin{pmatrix}\fi 1&2\cr 3&4\cr \ifx\endpmatrix\undefined}\else\end{pmatrix}\fi
```

We clean this to:
```tex
\begin{pmatrix} 1&2\\ 3&4\end{pmatrix}
```

Also: `\cr` → `\\`, unescape `\\` → `\`

### Plot Detection

We detect plot commands via regex and inject output options:

**plot family** (plot2d, plot3d, etc.):
```maxima
plot2d(sin(x), [x,0,6])
→ plot2d(sin(x), [x,0,6], [gnuplot_term, pngcairo], [gnuplot_out_file, "/tmp/plot.png"])
```

**draw family** (draw, draw2d, draw3d):
```maxima
draw2d(explicit(sin(x), x, 0, 6))
→ draw2d(explicit(sin(x), x, 0, 6), terminal=png, file_name="/tmp/plot")
```

### Type Guessing for Completions

Since calling `properties()` for each symbol is slow, we guess types from naming conventions:
- `%...` → constant
- `...p` → function (predicate)
- `is...`, `make...`, `set...`, etc. → function
- `..._...` → variable
- default → function

## License

MIT (or match your preferred license)

## Acknowledgments

- [maxima-jupyter](https://github.com/robert-dodier/maxima-jupyter) - inspiration and reference implementation
- [Maxima CAS](https://maxima.sourceforge.io/) - the computer algebra system
- [ipykernel](https://github.com/ipython/ipykernel) - Jupyter kernel framework
