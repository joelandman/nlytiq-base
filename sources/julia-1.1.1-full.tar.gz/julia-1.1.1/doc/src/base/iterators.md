# Iteration utilities

```@docs
Base.Iterators.Stateful
Base.Iterators.zip
Base.Iterators.enumerate
Base.Iterators.rest
Base.Iterators.countfrom
Base.Iterators.take
Base.Iterators.drop
Base.Iterators.cycle
Base.Iterators.repeated
Base.Iterators.product
Base.Iterators.flatten
Base.Iterators.partition
Base.Iterators.filter
Base.Iterators.reverse
```
