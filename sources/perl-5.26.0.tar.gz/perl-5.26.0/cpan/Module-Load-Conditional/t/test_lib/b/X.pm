package X;

our $VERSION = '0.02';

1;
