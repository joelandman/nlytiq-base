function x = SizeTester (desired_size)

  x = struct ("desired_size", desired_size);
  x = class (x, "SizeTester");

endfunction
