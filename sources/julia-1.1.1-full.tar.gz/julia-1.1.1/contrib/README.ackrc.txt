The 'ackrc' file is for Ack (http://beyondgrep.com/)
Place its contents in your ~/.ackrc file.
