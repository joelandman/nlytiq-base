#include <stdexcept>
void dummysymbol() {
  throw(std::runtime_error("string"));
}
