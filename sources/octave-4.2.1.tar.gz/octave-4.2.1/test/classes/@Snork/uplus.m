function s = uplus (s1)

  s = s1;

end
