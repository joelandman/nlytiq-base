function out = bling (m1, m2)

  out = 2;

end
