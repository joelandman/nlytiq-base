#!/usr/bin/env python3
"""Install the Maxima kernel into Jupyter."""

import json
import os
import sys
import shutil

def install_kernel():
    from jupyter_client.kernelspec import KernelSpecManager

    # Get the directory containing kernel.json
    kernel_dir = os.path.join(os.path.dirname(__file__), 'maxima_kernel')

    # Update kernel.json to use the venv's python
    kernel_json_path = os.path.join(kernel_dir, 'kernel.json')
    with open(kernel_json_path, 'r') as f:
        spec = json.load(f)

    # Use the current Python interpreter (from venv)
    spec['argv'][0] = sys.executable

    # Write updated spec to a temp location for installation
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_kernel_dir = os.path.join(tmpdir, 'maxima')
        os.makedirs(tmp_kernel_dir)

        with open(os.path.join(tmp_kernel_dir, 'kernel.json'), 'w') as f:
            json.dump(spec, f, indent=2)

        # Install the kernel spec
        ksm = KernelSpecManager()
        dest = ksm.install_kernel_spec(tmp_kernel_dir, 'maxima', user=True)
        print(f"Installed kernel to: {dest}")

    print("\nTo use the kernel:")
    print("  1. Run: jupyter notebook (or jupyter lab)")
    print("  2. Create a new notebook with 'Maxima' kernel")

if __name__ == '__main__':
    install_kernel()
