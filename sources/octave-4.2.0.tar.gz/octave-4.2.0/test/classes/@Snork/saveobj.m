function out = saveobj (in)

  out = in;
  out.cack = [];

end
