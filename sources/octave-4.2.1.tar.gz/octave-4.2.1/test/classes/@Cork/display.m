function display (s)

  disp ([inputname(1),'.click = ']);
  disp (' ');
  disp (s.click);

end
