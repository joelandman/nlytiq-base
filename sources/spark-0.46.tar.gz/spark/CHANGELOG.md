# changes

## 1.0.0

Hey! A 1.0! Now's a decent time as any. Starting to cut versions just for the
sake of things like Homebrew. So, might as well start with 1.0.

1.0 encompasses things that happened during
[the first week](http://zachholman.com/posts/from-hack-to-popular-project/)
of development.