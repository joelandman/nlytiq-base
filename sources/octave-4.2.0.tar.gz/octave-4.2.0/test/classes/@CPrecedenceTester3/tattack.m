function s = tattack (x, y)

  s = 'CPrecedenceTester3';

end
