function m = testclass (x,y)
  m = struct ('x',x,'y',y);
  m = class (m,"testclass");
endfunction
