function out = cack (in)

  out = in.cack;

end
