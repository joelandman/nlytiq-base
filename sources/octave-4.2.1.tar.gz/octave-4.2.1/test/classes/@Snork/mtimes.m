function s = mtimes (s1, s2)

  x1 = double (s1);
  x2 = double (s2);

  s = Snork (x1 * x2);

end
