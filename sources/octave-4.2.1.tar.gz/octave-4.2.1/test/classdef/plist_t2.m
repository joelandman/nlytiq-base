classdef plist_t2
  properties
    a = 1; b
  end
end
