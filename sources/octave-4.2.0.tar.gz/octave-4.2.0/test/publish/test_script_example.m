%% Headline title
%
% Some *bold*, _italic_, or |monospaced| Text with
% a <http://www.octave.org link to GNU Octave>.
%%

# "Real" Octave commands to be evaluated
sombrero ()

## Octave comment style supported as well
#
# * Bulleted list item 1
# * Bulleted list item 2
#
# # Numbered list item 1
# # Numbered list item 2