function x = double (snk)

  x = snk.gick;

end

