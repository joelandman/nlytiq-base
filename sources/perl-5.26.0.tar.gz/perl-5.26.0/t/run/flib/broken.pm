package broken;

use strict;
use warnings;

$x = 1;

1;
