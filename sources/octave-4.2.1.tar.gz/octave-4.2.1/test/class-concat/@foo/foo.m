function r = foo ()
  r = class (struct (), 'foo');
endfunction
