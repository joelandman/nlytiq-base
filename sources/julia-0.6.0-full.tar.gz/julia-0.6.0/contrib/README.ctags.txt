The 'ctags' file is for Exuberant CTags (http://ctags.sourceforge.net/)
Place its contents in your ~/.ctags file.
