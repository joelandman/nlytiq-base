// RUN: %llvmgcc %s -S -march=k8 -o /dev/null
// XFAIL: *
// XTARGET: x86,i386,i686
long double x;
