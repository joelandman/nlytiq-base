void *p = ((void*)&((char*)0)[0]);
