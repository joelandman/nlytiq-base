function display (s)

  disp ([inputname(1),'.bleek = ']);
  disp (' ');
  disp (s.bleek);

end
