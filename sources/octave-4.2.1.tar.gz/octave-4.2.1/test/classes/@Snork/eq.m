function b = eq (s1, s2)

  x1 = double (s1);
  x2 = double (s2);

  b = isequal (x1, x2);

end
