#!/bin/sh
# This file is a part of Julia. License is MIT: https://julialang.org/license

mvn compile exec:java
# requires maven and java 7
