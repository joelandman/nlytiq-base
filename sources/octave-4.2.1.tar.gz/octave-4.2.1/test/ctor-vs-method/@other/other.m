function r = other (varargin)
  __trace__ ('begin other/other');
  r = class (struct (), 'other');
  __trace__ ('end other/other');
end
