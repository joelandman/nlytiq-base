function display (s)

  disp ([inputname(1),'.geek = ']);
  disp (' ');
  disp (s.geek);

end
