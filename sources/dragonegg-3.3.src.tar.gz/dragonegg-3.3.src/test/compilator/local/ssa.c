int f(int x, int y, int b) { return b ? x : y; }
