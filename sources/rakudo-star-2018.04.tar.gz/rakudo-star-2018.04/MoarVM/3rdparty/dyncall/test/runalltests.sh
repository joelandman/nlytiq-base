A="callf ellipsis malloc_wx plain plain_c++ suite suite2 suite3 suite_floats callback_plain call_suite callback_suite"
for i in $A ; do
  $i/$i
done

