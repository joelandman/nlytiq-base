function s = tattack (x, y)

  s = 'CPrecedenceTester2';

end
