% function TWO returns item "Y"

function a = one (m)
  a = m.y;
endfunction
