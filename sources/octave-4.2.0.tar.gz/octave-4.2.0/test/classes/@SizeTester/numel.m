function n = numel (this)

  n = prod (this.desired_size);

endfunction
