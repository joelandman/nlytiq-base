function s = tattack (x, y)

  s = 'Snork';

end
