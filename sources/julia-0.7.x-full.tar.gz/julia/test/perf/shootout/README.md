This directory contains the Julia version of the "The
Computer Language Benchmarks Game":
https://benchmarksgame.alioth.debian.org/

The source code for all the benchmarks are available there:
https://alioth.debian.org/scm/viewvc.php/benchmarksgame/bench/?root=benchmarksgame

See specific Julia discussion here:
https://github.com/JuliaLang/julia/issues/660
