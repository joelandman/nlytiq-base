function display (s)

  disp ([inputname(1),'.gick = ']);
  disp (' ');
  disp (s.gick);

end
