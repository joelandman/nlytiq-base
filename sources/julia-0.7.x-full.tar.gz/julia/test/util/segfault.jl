# This file is a part of Julia. License is MIT: https://julialang.org/license

unsafe_load(convert(Ptr{UInt8},C_NULL))
