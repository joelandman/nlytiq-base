function out = myStash ()

  out = 4;

end
